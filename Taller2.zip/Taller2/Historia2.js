function historiaDeVida() {
    console.log("Había una vez una persona llamada Sebastian.");
    console.log("Desde pequeño tenía curiosidad por aprender cosas nuevas.");

    infancia();
    aprendizaje();
    desafios();
    logroFinal();
}

function infancia() {
    console.log("\nEn su infancia, cada día aprendía algo diferente.");

    for (let año = 1; año <= 5; año++) {
        console.log("Año " + año + ": descubriendo el mundo y soñando en grande.");
    }
}

function aprendizaje() {
    console.log("\nUn día decidió estudiar programación.");

    let diasEstudio = 1;

    while (diasEstudio <= 4) {
        console.log("Día " + diasEstudio + ": estudiando cada día con mucha motivación.");
        diasEstudio++;
    }
}

function desafios() {
    console.log("\nPero el camino no siempre fue fácil.");

    let errores = 3;

    if (errores > 0) {
        console.log("Cometió algunos errores mientras aprendía.");
    }

    for (let intento = 1; intento <= errores; intento++) {
        console.log("Intento " + intento + ": aprendiendo de los errores y mejorando.");
    }

    if (errores >= 3) {
        console.log("Gracias a esos errores, se volvió más fuerte y sabio.");
    }
}

function logroFinal() {
    console.log("\nCon esfuerzo y paciencia, Sebastián mejoró cada día.");
    console.log("Aprendió que rendirse nunca fue una opción.");
    console.log("Y así comenzó su camino para convertirse en un gran programador.");
}

historiaDeVida();